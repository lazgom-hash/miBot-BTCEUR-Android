import es.mibot.btceur.BinCodec;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class TestBinCodec {
    static void check(boolean yes) { if (!yes) throw new AssertionError(); }
    public static void main(String[] args) throws Exception {
        byte[] a = BinCodec.pack(1546300800L, 4000, 4100, 3900, 4050);
        check(a.length == 20 && BinCodec.timestamp(a, 0) == 1546300800L);
        ByteBuffer b = ByteBuffer.wrap(a).order(ByteOrder.LITTLE_ENDIAN);
        check(b.getInt() == 1546300800);
        check(b.getFloat() == 4000f && b.getFloat() == 4100f && b.getFloat() == 3900f && b.getFloat() == 4050f);
        byte[] c = BinCodec.pack(1546300860L, 4010, 4200, 4000, 4190);
        byte[] result = new byte[40];
        System.arraycopy(c, 0, result, 0, 20);
        System.arraycopy(a, 0, result, 20, 20);
        BinCodec.reverseRecords(result, 2);
        check(BinCodec.timestamp(result, 0) == 1546300800L);
        check(BinCodec.timestamp(result, 20) == 1546300860L);
        boolean threw = false;
        try {BinCodec.pack(1546300800L, 4000, 3900, 3900, 4100);} catch(java.io.IOException e){threw = true;}
        check(threw);
        System.out.println("PASS: 20 bytes EOC, little endian, orden cronológico y validaciones");
    }
}
