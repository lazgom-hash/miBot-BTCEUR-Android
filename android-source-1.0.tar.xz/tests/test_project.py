"""Comprueba estructuralmente el proyecto Android sin disponer del SDK."""
from pathlib import Path
import xml.etree.ElementTree as ET
import subprocess
root=Path(__file__).resolve().parents[1]
for f in (root/'app/src/main').rglob('*.xml'):
    ET.parse(f)
    print('XML OK', f.relative_to(root))
assert 'INTERNET' in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'ACTION_CREATE_DOCUMENT' in (root/'app/src/main/java/es/mibot/btceur/MainActivity.java').read_text()
assert 'FOREGROUND_SERVICE_DATA_SYNC' in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'dataSync' in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'getString("ready_file"' in (root/'app/src/main/java/es/mibot/btceur/DownloadService.java').read_text()
for u in ['Bitstamp','20 bytes','reanudar']:
    assert u.lower() in (root/'LEEME.txt').read_text().lower()
print('PASS: XML y estructura nativa Android')
