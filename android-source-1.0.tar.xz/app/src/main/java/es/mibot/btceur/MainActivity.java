package es.mibot.btceur;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends Activity {
    private static final int CREATE_BIN = 1100;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private Button from, until, start, pause, export;
    private EditText endClock;
    private TextView state, detail, percent;
    private ProgressBar bar;
    private String fromDate = "2019-01-01", untilDate = "2026-06-10";
    private File exportSource;
    private final Runnable refreshTask = new Runnable() {
        @Override public void run() {
            refreshStatus();
            handler.postDelayed(this, 1200);
        }
    };

    @Override public void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        setContentView(R.layout.activity_main);
        from = findViewById(R.id.btnFrom);
        until = findViewById(R.id.btnUntil);
        start = findViewById(R.id.btnStart);
        pause = findViewById(R.id.btnPause);
        export = findViewById(R.id.btnExport);
        endClock = findViewById(R.id.inputTime);
        state = findViewById(R.id.txtState);
        detail = findViewById(R.id.txtDetail);
        percent = findViewById(R.id.txtPercent);
        bar = findViewById(R.id.progress);
        fromDate = getPreferences(MODE_PRIVATE).getString("from", fromDate);
        untilDate = getPreferences(MODE_PRIVATE).getString("until", untilDate);
        endClock.setText(getPreferences(MODE_PRIVATE).getString("clock", "00:23"));
        from.setOnClickListener(v -> showDatePicker(true));
        until.setOnClickListener(v -> showDatePicker(false));
        start.setOnClickListener(v -> startJob());
        pause.setOnClickListener(v -> {
            Intent intent = new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_PAUSE);
            startService(intent);
            toast("Pausa solicitada; los datos descargados se conservarán");
        });
        export.setOnClickListener(v -> chooseExportDestination());
        updateDates();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 222);
        }
    }

    private void showDatePicker(boolean isFrom) {
        String value = isFrom ? fromDate : untilDate;
        String[] parts = value.split("-");
        DatePickerDialog dialog = new DatePickerDialog(this, (view, year, month, day) -> {
            String next = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
            if (isFrom) fromDate = next; else untilDate = next;
            getPreferences(MODE_PRIVATE).edit().putString("from", fromDate).putString("until", untilDate).apply();
            updateDates();
        }, Integer.parseInt(parts[0]), Integer.parseInt(parts[1]) - 1, Integer.parseInt(parts[2]));
        dialog.show();
    }

    private void updateDates() {
        from.setText(fromDate);
        until.setText(untilDate);
    }

    private long utc(String date, int hour, int minute) throws Exception {
        Date d = sdf.parse(date);
        if (d == null) throw new IllegalArgumentException("Fecha inválida");
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        cal.setTime(d); cal.add(Calendar.HOUR_OF_DAY, hour); cal.add(Calendar.MINUTE, minute);
        return cal.getTimeInMillis() / 1000;
    }

    private void startJob() {
        try {
            if (DownloadService.isRunning()) { toast("Ya se está descargando"); return; }
            String clock = endClock.getText().toString().trim();
            if (!clock.matches("(?:[01]\\d|2[0-3]):[0-5]\\d")) {
                toast("Escribe una hora UTC válida: HH:mm"); return;
            }
            int hour = Integer.parseInt(clock.substring(0, 2));
            int minute = Integer.parseInt(clock.substring(3));
            long fromSeconds = utc(fromDate, 0, 0), toSeconds = utc(untilDate, hour, minute);
            if (toSeconds <= fromSeconds || toSeconds > System.currentTimeMillis() / 1000 - 60) {
                toast("Revisa el periodo: el final debe ser posterior al inicio y no estar en el futuro");
                return;
            }
            if (fromSeconds < 60L || toSeconds > 4294967295L) {
                toast("Fechas fuera del rango del formato BIN"); return;
            }
            getPreferences(MODE_PRIVATE).edit().putString("clock", clock).apply();
            Intent intent = new Intent(this, DownloadService.class).setAction(DownloadService.ACTION_START);
            intent.putExtra("start", fromSeconds);
            intent.putExtra("end", toSeconds);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
            toast("Descarga iniciada; puedes dejar la aplicación en segundo plano");
        } catch (Exception ex) {
            toast("Error de fechas: " + ex.getMessage());
        }
    }

    private void refreshStatus() {
        android.content.SharedPreferences prefs = getSharedPreferences(DownloadService.PREFS, MODE_PRIVATE);
        String status = prefs.getString("state", "Listo para comenzar");
        String info = prefs.getString("detail", "Sin descarga iniciada");
        int progress = prefs.getInt("progress", 0);
        boolean running = DownloadService.isRunning();
        state.setText(status);
        detail.setText(info);
        bar.setProgress(progress);
        percent.setText(String.format(Locale.getDefault(), "%.1f %%", progress / 10.0));
        start.setEnabled(!running);
        pause.setEnabled(running);
        from.setEnabled(!running);
        until.setEnabled(!running);
        endClock.setEnabled(!running);
        File f = DownloadService.getLastOutput(this);
        export.setEnabled(f != null && f.isFile());
    }

    private void chooseExportDestination() {
        File f = DownloadService.getLastOutput(this);
        if (f == null || !f.isFile()) {toast("Todavía no hay BIN completo");return;}
        exportSource = f;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, f.getName());
        startActivityForResult(intent, CREATE_BIN);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_BIN || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (exportSource == null || !exportSource.isFile()) { toast("No se encuentra el archivo terminado"); return; }
        Uri destination = data.getData();
        File source = exportSource;
        export.setEnabled(false);
        state.setText("Guardando BIN en el teléfono…");
        new Thread(() -> {
            Exception failure = null;
            try (FileInputStream input = new FileInputStream(source);
                 OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                if (output == null) throw new IOException("No se pudo abrir el destino");
                byte[] buffer = new byte[1024 * 1024];
                int n;
                while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n);
                output.flush();
            } catch (Exception e) {
                failure = e;
            }
            Exception result = failure;
            runOnUiThread(() -> {
                export.setEnabled(true);
                toast(result == null ? "BIN guardado correctamente" : "Fallo al guardar: " + result.getMessage());
                refreshStatus();
            });
        }, "mibot-export").start();
    }

    @Override public void onStart() {
        super.onStart();
        handler.post(refreshTask);
    }
    @Override public void onStop() {
        handler.removeCallbacks(refreshTask);
        super.onStop();
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
