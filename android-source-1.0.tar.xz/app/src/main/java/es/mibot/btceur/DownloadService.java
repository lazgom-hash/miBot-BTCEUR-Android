package es.mibot.btceur;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.StatFs;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

public class DownloadService extends Service {
    public static final String ACTION_START = "es.mibot.btceur.START";
    public static final String ACTION_PAUSE = "es.mibot.btceur.PAUSE";
    public static final String PREFS = "download_status";
    private static final String TAG = "miBotBTCEUR";
    private static final String CHANNEL_ID = "historico_btceur";
    private static final int NOTIFY_ID = 701;
    private static final String URL_BASE = "https://www.bitstamp.net/api/v2/ohlc/btceur/?step=60&limit=1000&end=";
    private static volatile boolean running = false;
    private static volatile boolean pauseRequested = false;
    private volatile int progress = 0;
    private volatile long lastNotifyMs = 0;
    private NotificationManager manager;
    private String fileName;
    private long from, until;

    public static boolean isRunning() {return running;}
    public static File getLastOutput(Context ctx) {
        String path = ctx.getSharedPreferences(PREFS, MODE_PRIVATE).getString("ready_file", "");
        if (path.isEmpty()) return null;
        File f = new File(path);
        return f.exists() ? f : null;
    }

    @Override public void onCreate() {
        super.onCreate();
        manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Descarga de datos miBot", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Progreso de descarga BTC/EUR a un minuto");
            manager.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_PAUSE.equals(intent.getAction())) {
            pauseRequested = true;
            status("Pausando…", "Se conservará todo lo descargado", progress);
            if (!running) stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction()) || running) return START_NOT_STICKY;
        long requestFrom = intent.getLongExtra("start", 0), requestTo = intent.getLongExtra("end", 0);
        if (requestFrom <= 0 || requestTo <= requestFrom || requestTo > System.currentTimeMillis() / 1000 - 60) {
            status("Error", "Periodo solicitado inválido", 0);
            stopSelf();
            return START_NOT_STICKY;
        }
        from = requestFrom;
        until = requestTo;
        fileName = String.format(Locale.US, "BTCEUR_1m_%d_%d_BITSTAMP_20B.bin", from, until);
        running = true;
        pauseRequested = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("ready_file").apply();
        progress = 0;
        // Android requires foreground-service promotion promptly after startForegroundService().
        try {
            startForeground(NOTIFY_ID, notification("Preparando descarga…", 0, true));
        } catch (Exception e) {
            running = false;
            status("Error de permisos", "No se pudo crear el servicio en primer plano: " + e.getMessage(), 0);
            stopSelf();
            return START_NOT_STICKY;
        }
        new Thread(() -> {
            PowerManager.WakeLock wakeLock = null;
            try {
                PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
                if (power != null) {
                    wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "miBot:BTCEURDownload");
                    wakeLock.acquire(4 * 60 * 60 * 1000L); // max 4 h, always released in finally
                }
                runDownload();
                if (pauseRequested) status("Descarga pausada", "Pulsa Descargar / Reanudar para continuar", progress);
            } catch (PauseSignal ex) {
                status("Descarga pausada", "Progreso conservado; pulsa Descargar / Reanudar", progress);
            } catch (Throwable ex) {
                Log.e(TAG, "Fallo de descarga", ex);
                status("Descarga interrumpida", ex.getMessage() == null ? ex.toString() : ex.getMessage(), progress);
            } finally {
                if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
                running = false;
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
        }, "mibot-bitstamp-downloader").start();
        return START_NOT_STICKY;
    }

    private Notification notification(String text, int permille, boolean showPause) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 11, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("miBot · BTC/EUR 1m")
                .setContentText(text)
                .setContentIntent(openPi)
                .setOngoing(showPause)
                .setOnlyAlertOnce(true)
                .setProgress(1000, Math.max(0, Math.min(1000, permille)), false);
        if (showPause) {
            PendingIntent pausePi = PendingIntent.getService(this, 12,
                    new Intent(this, DownloadService.class).setAction(ACTION_PAUSE),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause, "Pausar", pausePi).build());
        }
        return b.build();
    }

    private void status(String state, String detail, int permille) {
        progress = Math.max(0, Math.min(1000, permille));
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        p.edit().putString("state", state).putString("detail", detail)
                .putInt("progress", progress).apply();
        long now = SystemClock.elapsedRealtime();
        if (running && now - lastNotifyMs > 1800) {
            manager.notify(NOTIFY_ID, notification(state + " · " + progress / 10.0 + "%", progress, true));
            lastNotifyMs = now;
        }
    }

    private File workDir() throws IOException {
        File root = getExternalFilesDir(null);
        if (root == null) throw new IOException("El almacenamiento externo de la app no está disponible");
        File dir = new File(root, "datos");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("No se puede crear carpeta temporal");
        return dir;
    }

    private static final class Candle {
        long t;
        double o, h, l, c;
        Candle(JSONObject j) throws Exception {
            t = Long.parseLong(j.getString("timestamp"));
            o = Double.parseDouble(j.getString("open"));
            h = Double.parseDouble(j.getString("high"));
            l = Double.parseDouble(j.getString("low"));
            c = Double.parseDouble(j.getString("close"));
        }
    }
    private static final class PauseSignal extends Exception { }

    private void checkPause() throws PauseSignal {
        if (pauseRequested || Thread.currentThread().isInterrupted()) throw new PauseSignal();
    }
    private void sleep(long millis) throws PauseSignal {
        long end = SystemClock.elapsedRealtime() + millis;
        while (SystemClock.elapsedRealtime() < end) {
            checkPause();
            SystemClock.sleep(Math.min(250, end - SystemClock.elapsedRealtime()));
        }
    }
    private int positionPercent(long oldest) {
        double fraction = (double) (until - oldest) / (until - from);
        return (int) Math.floor(Math.max(0, Math.min(1, fraction)) * 1000);
    }
    private String fmt(long timestamp) {
        SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy HH:mm 'UTC'", Locale.getDefault());
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(timestamp * 1000L));
    }

    private JSONArray fetchPage(long endSeconds) throws Exception {
        Exception finalError = null;
        for (int attempt = 0; attempt < 9; attempt++) {
            checkPause();
            HttpURLConnection conn = null;
            try {
                URL u = new URL(URL_BASE + endSeconds);
                conn = (HttpURLConnection) u.openConnection();
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent", "miBot-Android-BTCEUR/1.0");
                conn.setConnectTimeout(25000);
                conn.setReadTimeout(45000);
                conn.setInstanceFollowRedirects(true);
                int http = conn.getResponseCode();
                if (http != 200) throw new IOException("Bitstamp devolvió HTTP " + http);
                try (InputStream in = new BufferedInputStream(conn.getInputStream())) {
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream(160000);
                    byte[] chunk = new byte[8192];
                    int count;
                    while ((count = in.read(chunk)) != -1) {
                        checkPause();
                        buffer.write(chunk, 0, count);
                        if (buffer.size() > 4 * 1024 * 1024) throw new IOException("Respuesta JSON inesperadamente grande");
                    }
                    JSONObject json = new JSONObject(buffer.toString("UTF-8"));
                    if (!json.has("data") || json.optJSONObject("data") == null ||
                            json.getJSONObject("data").optJSONArray("ohlc") == null) {
                        throw new IOException("Respuesta inesperada de Bitstamp");
                    }
                    return json.getJSONObject("data").getJSONArray("ohlc");
                }
            } catch (PauseSignal ex) {
                throw ex;
            } catch (Exception ex) {
                finalError = ex;
                if (attempt == 8) break;
                long seconds = Math.min(90L, 2L << attempt);
                status("Reintentando conexión (" + (attempt + 1) + "/9)",
                        ex.getMessage() + " · esperamos " + seconds + " s", progress);
                sleep(seconds * 1000L);
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw new IOException("Conexión fallida tras 9 intentos: " + finalError, finalError);
    }

    private long lastTimestamp(File partial) throws Exception {
        if (!partial.exists() || partial.length() == 0) return -1;
        if (partial.length() % 20 != 0) throw new IOException("Parcial inconsistente (tamaño no múltiplo de 20)");
        try (RandomAccessFile file = new RandomAccessFile(partial, "r")) {
            file.seek(file.length() - 20);
            byte[] b = new byte[20];
            file.readFully(b);
            long t = BinCodec.timestamp(b, 0);
            if (t < from || t > until) throw new IOException("Parcial no corresponde a las fechas seleccionadas");
            return t;
        }
    }

    private void runDownload() throws Exception {
        File dir = workDir();
        File finished = new File(dir, fileName);
        File partial = new File(dir, fileName + ".part");
        File temp = new File(dir, fileName + ".tmp");
        if (finished.exists() && finished.length() % 20 == 0 && finished.length() > 0) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString("ready_file", finished.getAbsolutePath()).apply();
            status("BIN ya terminado", finished.getName() + " · pulsa Guardar BIN", 1000);
            return;
        }
        if (!partial.exists()) {
            long totalRecords = ((until - from) / 60) + 1;
            long storageNeeded = totalRecords * 20 * 2 + 20L * 1024 * 1024;
            StatFs fs = new StatFs(dir.getAbsolutePath());
            if (fs.getAvailableBytes() < storageNeeded) {
                throw new IOException("Espacio insuficiente. Necesitas aproximadamente "
                        + (storageNeeded / 1048576) + " MB libres para crear el BIN.");
            }
        }
        long previous = lastTimestamp(partial);
        long cursor = previous < 0 ? until : previous - 60L;
        long count = partial.exists() ? partial.length() / 20 : 0;
        if (previous > 0) status("Reanudando descarga", "Conservadas " + count + " velas; desde " + fmt(previous), positionPercent(previous));

        if (cursor >= from) {
            try (FileOutputStream stream = new FileOutputStream(partial, true);
                    BufferedOutputStream output = new BufferedOutputStream(stream, 262144)) {
                long pages = 0;
                while (cursor >= from) {
                    checkPause();
                    JSONArray raw = fetchPage(cursor);
                    List<Candle> page = new ArrayList<>();
                    boolean beforeFrom = false;
                    Set<Long> seen = new HashSet<>();
                    for (int i = 0; i < raw.length(); i++) {
                        Candle item = new Candle(raw.getJSONObject(i));
                        if (item.t < from) {beforeFrom = true; continue;}
                        if (item.t > cursor) continue;
                        if (!seen.add(item.t)) continue;
                        // Validate values even for network data before writing the partial file.
                        BinCodec.pack(item.t, item.o, item.h, item.l, item.c);
                        page.add(item);
                    }
                    if (page.isEmpty()) {
                        if (beforeFrom) break;
                        throw new IOException("Bitstamp no entregó velas anteriores a " + fmt(cursor)
                                + ". Se han conservado los datos para reintentar.");
                    }
                    page.sort((a, b) -> Long.compare(b.t, a.t));
                    long oldest = page.get(page.size() - 1).t;
                    if (oldest > cursor) throw new IOException("La API no está retrocediendo correctamente");
                    for (Candle candle : page) {
                        output.write(BinCodec.pack(candle.t, candle.o, candle.h, candle.l, candle.c));
                    }
                    output.flush(); // each page is fully persisted before its completion is reported
                    pages++;
                    count += page.size();
                    cursor = oldest - 60L;
                    status("Descargando BTC/EUR", "Velas: " + String.format(Locale.getDefault(), "%,d", count)
                            + " · alcanzado: " + fmt(oldest) + " · páginas: " + pages,
                            positionPercent(oldest));
                    sleep(250); // polite pacing; safe for the public API
                }
                stream.getFD().sync();
            }
        }
        checkPause();
        // A valid completion must have reached the beginning of the chosen period.
        long last = lastTimestamp(partial);
        if (last < 0 || last > from + 86400L) {
            throw new IOException("Origen no cubre el inicio solicitado (más de un día de desfase): " + fmt(last));
        }
        status("Preparando BIN", "Invirtiendo y comprobando orden cronológico…", 1000);
        finish(partial, temp, finished);
    }

    private void finish(File partial, File temp, File target) throws Exception {
        long count = partial.length() / 20;
        if (count == 0) throw new IOException("Descarga vacía");
        long first = -1, last = -1, missing = 0, gaps = 0, maxGap = 0, processed = 0;
        // Transform reverse-chronological page storage into chronological miBot BIN.
        // We validate while writing and never publish the final path until finished.
        try (RandomAccessFile input = new RandomAccessFile(partial, "r");
             FileOutputStream fos = new FileOutputStream(temp);
             BufferedOutputStream output = new BufferedOutputStream(fos, 1024 * 1024)) {
            long remaining = count;
            final int chunkRecords = 8192;
            while (remaining > 0) {
                checkPause();
                int n = (int) Math.min(chunkRecords, remaining);
                remaining -= n;
                byte[] data = new byte[n * 20];
                input.seek(remaining * 20);
                input.readFully(data);
                BinCodec.reverseRecords(data, n);
                for (int i = 0; i < n; i++) {
                    int pos = i * 20;
                    ByteBuffer b = ByteBuffer.wrap(data, pos, 20).order(ByteOrder.LITTLE_ENDIAN);
                    long ts = Integer.toUnsignedLong(b.getInt());
                    float o = b.getFloat(), h = b.getFloat(), l = b.getFloat(), c = b.getFloat();
                    if (!(o > 0 && l > 0 && l <= o && o <= h && l <= c && c <= h)
                            || ts < from || ts > until || ts % 60 != 0) {
                        throw new IOException("OHLC inválida en " + fmt(ts));
                    }
                    if (first == -1) first = ts;
                    if (last != -1) {
                        long delta = ts - last;
                        if (delta <= 0 || delta % 60 != 0) throw new IOException("Timestamps duplicados o desordenados: " + fmt(ts));
                        if (delta > 60) {
                            gaps++; long miss = delta / 60 - 1;
                            missing += miss; maxGap = Math.max(maxGap, miss);
                        }
                    }
                    last = ts;
                    processed++;
                }
                output.write(data);
                if ((processed / chunkRecords) % 10 == 0) {
                    status("Validando BIN", processed + " de " + count + " velas comprobadas", 1000);
                }
            }
            output.flush();
            fos.getFD().sync();
        } catch (Exception e) {
            // Keep both the reverse downloaded file and the temp file for diagnosis;
            // on a new attempt the temp file is recreated from the intact .part file.
            throw e;
        }
        if (first < from || first - from > 86400L || last > until || until - last > 86400L) {
            throw new IOException("Histórico insuficiente: primera " + fmt(first) + ", última " + fmt(last));
        }
        missing += (first - from) / 60 + (until - last) / 60;
        Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        File report = new File(target.getParentFile(), target.getName() + ".informe.txt");
        String text = "miBot · BTC/EUR 1m REAL · BITSTAMP (no OKX)\n"
                + "Inicio: " + fmt(first) + "\nFin: " + fmt(last) + "\n"
                + "Velas: " + count + "\nHuecos: " + gaps + "\n"
                + "Minutos sin vela: " + missing + "\nHueco máximo (minutos): " + maxGap + "\n"
                + "Formato: 20 bytes LE (uint32 UTC + float32 O H L C)\n"
                + "Sin interpolaciones ni conversión USD/EUR; sin spread ni comisiones de OKX.\n";
        try (OutputStream output = new FileOutputStream(report)) { output.write(text.getBytes("UTF-8")); }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("ready_file", target.getAbsolutePath()).apply();
        // Only remove the partial after the final file and report exist.
        if (!partial.delete()) Log.w(TAG, "No se pudo borrar parcial, pero el BIN está listo");
        status("BIN terminado ✓", count + " velas · " + (target.length() / 1048576) + " MB · pulsa GUARDAR BIN", 1000);
        manager.notify(NOTIFY_ID + 1, notification("BIN completo: pulsa para exportarlo", 1000, false));
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
