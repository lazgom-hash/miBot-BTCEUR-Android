package es.mibot.btceur;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Pure Java EOC miBot codec. Exactly 20 bytes per OHLC record, little endian. */
public final class BinCodec {
    public static final int RECORD_SIZE = 20;
    private BinCodec() { }

    public static byte[] pack(long timestamp, double open, double high, double low, double close) throws IOException {
        if (timestamp < 0 || timestamp > 4294967295L || timestamp % 60 != 0 ||
            !Double.isFinite(open) || !Double.isFinite(high) || !Double.isFinite(low) ||
            !Double.isFinite(close) || !(low > 0 && low <= open && open <= high && low <= close && close <= high)) {
            throw new IOException("Vela OHLC o marca temporal inválida: " + timestamp);
        }
        ByteBuffer b = ByteBuffer.allocate(RECORD_SIZE).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt((int) timestamp);
        b.putFloat((float) open); b.putFloat((float) high);
        b.putFloat((float) low); b.putFloat((float) close);
        return b.array();
    }
    public static long timestamp(byte[] b, int off) {
        return Integer.toUnsignedLong(ByteBuffer.wrap(b, off, RECORD_SIZE).order(ByteOrder.LITTLE_ENDIAN).getInt());
    }
    public static void reverseRecords(byte[] b, int records) {
        if (b.length < records * RECORD_SIZE) throw new IllegalArgumentException("Bloque incompleto");
        for (int i = 0, j = records - 1; i < j; i++, j--) {
            int a = i * RECORD_SIZE, z = j * RECORD_SIZE;
            for (int k = 0; k < RECORD_SIZE; k++) {
                byte t = b[a + k]; b[a + k] = b[z + k]; b[z + k] = t;
            }
        }
    }
}
