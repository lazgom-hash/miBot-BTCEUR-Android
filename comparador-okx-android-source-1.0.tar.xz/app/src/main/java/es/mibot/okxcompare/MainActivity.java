package es.mibot.okxcompare;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView view;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,17,33));
        getWindow().setNavigationBarColor(Color.rgb(11,17,33));
        view = new WebView(this);
        view.setBackgroundColor(Color.rgb(11,17,33));
        setContentView(view);
        WebSettings s=view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        view.setWebChromeClient(new WebChromeClient());
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest req) {
                if (!req.isForMainFrame()) return false;
                Uri u=req.getUrl();
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
                    catch (Exception e) { Toast.makeText(MainActivity.this,"Sin navegador externo",Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return true;
            }
        });
        view.addJavascriptInterface(new Bridge(), "MiBotAndroid");
        try (InputStream i=getAssets().open("index.html"); ByteArrayOutputStream b=new ByteArrayOutputStream()) {
            byte[] buf=new byte[8192]; int x;
            while((x=i.read(buf))!=-1) b.write(buf,0,x);
            String html=b.toString("UTF-8");
            // HTML local confiable con origen HTTPS; sólo obtiene el CSV público.
            view.loadDataWithBaseURL("https://raw.githubusercontent.com/", html, "text/html", "UTF-8", null);
        } catch(Exception e) {
            Toast.makeText(this,"Error al abrir el panel: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    public final class Bridge {
        @JavascriptInterface public void saveCsv(String csv) {
            if (csv==null || csv.length()<10 || csv.length()>20_000_000) return;
            try {
                if (Build.VERSION.SDK_INT < 29) {
                    runOnUiThread(()->Toast.makeText(MainActivity.this,"Exportación disponible en Android 10 o posterior",Toast.LENGTH_LONG).show());
                    return;
                }
                String date=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.ROOT).format(new Date());
                String name="miBot_OKX_observaciones_"+date+".csv";
                ContentValues v=new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                v.put(MediaStore.Downloads.MIME_TYPE,"text/csv");
                v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                if(uri==null) throw new IllegalStateException("No se pudo guardar en Descargas");
                try(OutputStream o=getContentResolver().openOutputStream(uri)) {
                    if(o==null)throw new IllegalStateException("Salida no disponible");
                    o.write(csv.getBytes(StandardCharsets.UTF_8));
                }
                runOnUiThread(()->Toast.makeText(MainActivity.this,"CSV guardado en Descargas",Toast.LENGTH_LONG).show());
            }catch(Exception e){
                String msg=e.getMessage();
                runOnUiThread(()->Toast.makeText(MainActivity.this,"Error al exportar: "+msg,Toast.LENGTH_LONG).show());
            }
        }
    }
    @Override public void onBackPressed(){ if(view!=null&&view.canGoBack())view.goBack();else super.onBackPressed(); }
    @Override protected void onDestroy(){if(view!=null){view.removeJavascriptInterface("MiBotAndroid");view.destroy();}super.onDestroy();}
}
