from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
for path in root.rglob('*.xml'):
 ET.parse(path)
html=(root/'app/src/main/assets/index.html').read_text()
java=(root/'app/src/main/java/es/mibot/okxcompare/MainActivity.java').read_text()
assert 'fetch(FILE+' in html
assert 'window.MiBotAndroid.saveCsv' in html
assert 'android.permission.INTERNET' in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'saveCsv(String csv)' in java
assert 'WebSettings.MIXED_CONTENT_NEVER_ALLOW' in java
print('PASS: XML válido, panel y puente Android de exportación CSV')
