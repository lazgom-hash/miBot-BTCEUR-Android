#!/usr/bin/env python3
"""Comparador público de profundidad OKX BTC-EUR frente a BTC-USD.

No claves, no órdenes, no conexión con cuentas. Recolecta pares coincidentes.
Sólo hace una medición por ejecución; el cron de GitHub programa las llamadas.
"""
from __future__ import annotations
import csv
import datetime as dt
import json
import math
import os
import pathlib
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
DATA = ROOT / 'data'
DATA.mkdir(parents=True, exist_ok=True)
CSV_PATH = DATA / 'observaciones.csv'
STATUS_PATH = DATA / 'estado.json'
BASE = os.getenv('OKX_BASE_URL', 'https://www.okx.com').rstrip('/')
EUR_SYMBOL = 'BTC-EUR'
USD_SYMBOLS = ('BTC-USD', 'BTC-USDC')
SIZES_EUR = (200, 300, 1000, 5000, 15000)
FEE_BPS = 10.0 # Compra y venta, cada una 0,10 %
MAX_AGE_MS = 60_000
MAX_PAIR_SKEW_MS = 30_000
FIELDS = ['fecha_utc', 'mercado', 'simbolo_real', 'fecha_libro_utc', 'antiguedad_ms',
          'bid', 'ask', 'medio', 'spread_bps', 'cambio_usd_eur_implicito',
          'bid_btc_50', 'ask_btc_50'] + [f'ida_vuelta_{s}eur_bps' for s in SIZES_EUR] + [f'cobertura_{s}eur' for s in SIZES_EUR]


def _fetch(path, params):
    url = BASE + path + '?' + urllib.parse.urlencode(params)
    headers = {'User-Agent': 'miBot-OKX-Comparator/1.0 (public-research)',
               'Accept': 'application/json'}
    last_error = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=16) as r:
                content = r.read(400_000)
            item = json.loads(content)
            if not isinstance(item, dict) or str(item.get('code')) != '0' or not item.get('data'):
                raise ValueError('Respuesta OKX: '+str(item.get('msg', 'sin datos'))[:120])
            return item['data'][0]
        except (urllib.error.URLError, TimeoutError, ValueError, json.JSONDecodeError) as e:
            last_error = str(e)
            if attempt < 2:
                time.sleep(2 * (attempt+1))
    raise RuntimeError(f'Error consultando {path} {params.get("instId")}: {last_error}')


def _side(values, reverse=False):
    res = []
    for entry in values[:50]:
        p, b = float(entry[0]), float(entry[1])
        if not math.isfinite(p) or not math.isfinite(b) or p <= 0 or b < 0:
            raise ValueError('Nivel de libro no válido')
        if b:
            res.append((p, b))
    if not res:
        raise ValueError('Libro vacío')
    prices = [p for p, _ in res]
    if any((prices[i] < prices[i+1] if reverse else prices[i] > prices[i+1]) for i in range(len(prices)-1)):
        raise ValueError('Libro desordenado')
    return res


def parse_book(obj, now_ms):
    bids = _side(obj['bids'], reverse=True)
    asks = _side(obj['asks'])
    if bids[0][0] >= asks[0][0]:
        raise ValueError('Libro cruzado o inválido')
    server_ms = int(obj['ts'])
    age = now_ms - server_ms
    if age < -5_000 or age > MAX_AGE_MS:
        raise ValueError(f'Libro desactualizado: edad={age} ms')
    mid = (bids[0][0]+asks[0][0])/2
    return {'bids':bids,'asks':asks,'ts':server_ms,'age_ms':age,
            'bid':bids[0][0],'ask':asks[0][0],'mid':mid,
            'spread_bps':(asks[0][0]-bids[0][0])/mid*10_000}


def buy_with_quote(asks, budget_quote):
    """Mercado: gasta presupuesto en quote, sin comisión, devuelve BTC o None."""
    remaining = budget_quote
    btc = 0.0
    for p, q in asks:
        spent = min(remaining, p*q)
        btc += spent / p
        remaining -= spent
        if remaining <= max(1e-8, budget_quote*1e-12):
            return btc
    return None


def sell_btc(bids, btc):
    remaining = btc
    quote = 0.0
    for p, q in bids:
        take = min(remaining, q)
        quote += take*p
        remaining -= take
        if remaining <= max(1e-12, btc*1e-12):
            return quote
    return None


def roundtrip_bps(book, quote_budget):
    """Coste real de compra taker + liquidación inmediata taker, misma cantidad BTC.

    Precio ejecutable simulado con 50 niveles públicos; fees 0,1 % por lado.
    No estima el TP maker de la martingala ni garantiza ejecución futura.
    """
    btc = buy_with_quote(book['asks'], quote_budget)
    if btc is None:
        return None
    proceeds = sell_btc(book['bids'], btc)
    if proceeds is None:
        return None
    net = proceeds*(1-FEE_BPS/10_000)
    initial = quote_budget*(1+FEE_BPS/10_000)
    return (1-net/initial)*10_000


def to_row(book, market, symbol, fx, now):
    quote_factor = fx if market == 'USD' else 1
    date = dt.datetime.fromtimestamp(book['ts']/1000, dt.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
    row = {'fecha_utc': now, 'mercado':market,'simbolo_real':symbol,
           'fecha_libro_utc':date,'antiguedad_ms':book['age_ms'],
           'bid':round(book['bid'],8),'ask':round(book['ask'],8),
           'medio':round(book['mid'],8),'spread_bps':round(book['spread_bps'],4),
           'cambio_usd_eur_implicito':round(fx,8),
           'bid_btc_50':round(sum(q for _,q in book['bids']),8),
           'ask_btc_50':round(sum(q for _,q in book['asks']),8)}
    for size in SIZES_EUR:
        cost=roundtrip_bps(book,size*quote_factor)
        row[f'ida_vuelta_{size}eur_bps']=round(cost,4) if cost is not None else ''
        row[f'cobertura_{size}eur']=int(cost is not None)
    return row


def save_status(ok, now, msg, usd_symbol=None, obs=None):
    existing={}
    if STATUS_PATH.exists():
        try: existing=json.loads(STATUS_PATH.read_text(encoding='utf-8'))
        except Exception: pass
    existing.update({'ultimo_intento_utc':now,'estado':'ok' if ok else 'error',
                     'mensaje':msg[:300], 'tarifa_compra_bps':FEE_BPS,
                     'tarifa_venta_bps':FEE_BPS,
                     'nota':'Libro BTC-USD unificado en OKX Europa; ejecución simulada taker, no TP real'})
    if usd_symbol:existing['simbolo_usd']=usd_symbol
    if ok:
        existing['ultima_muestra_utc']=now
        existing['muestras_totales']=int(existing.get('muestras_totales',0))+1
        existing['ultima_observacion']=obs
    STATUS_PATH.write_text(json.dumps(existing,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def append_pair(rows):
    exists=CSV_PATH.exists() and CSV_PATH.stat().st_size>0
    with CSV_PATH.open('a',newline='',encoding='utf-8') as h:
        writer=csv.DictWriter(h,fieldnames=FIELDS)
        if not exists:writer.writeheader()
        writer.writerows(rows)


def main():
    now_ms=int(time.time()*1000)
    now=dt.datetime.fromtimestamp(now_ms/1000, dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')
    try:
        eur=parse_book(_fetch('/api/v5/market/books', {'instId':EUR_SYMBOL,'sz':'50'}), int(time.time()*1000))
        errs=[]
        usd=None
        usd_symbol=None
        for symbol in USD_SYMBOLS:
            try:
                usd=parse_book(_fetch('/api/v5/market/books', {'instId':symbol,'sz':'50'}),int(time.time()*1000))
                usd_symbol=symbol
                break
            except Exception as exc: errs.append(f'{symbol}: {exc}')
        if usd is None: raise RuntimeError('Sin libro USD válido. '+'; '.join(errs))
        if abs(eur['ts']-usd['ts'])>MAX_PAIR_SKEW_MS:
            raise RuntimeError('Diferencia temporal entre libros >30 s')
        fx=usd['mid']/eur['mid']
        if not 0.7<fx<2.0: raise ValueError('Cambio implícito improbable')
        rows=[to_row(eur,'EUR',EUR_SYMBOL,fx,now),to_row(usd,'USD',usd_symbol,fx,now)]
        append_pair(rows)
        save_status(True,now,'Muestra válida: 2 mercados',usd_symbol,
                    {'spread_eur_bps':rows[0]['spread_bps'], 'spread_usd_bps':rows[1]['spread_bps'],
                     'fx':round(fx,6)})
        print(f'OK {now} {EUR_SYMBOL} vs {usd_symbol} | spread {rows[0]["spread_bps"]:.2f}/{rows[1]["spread_bps"]:.2f} bps | FX {fx:.5f}')
    except Exception as e:
        save_status(False,now,type(e).__name__+': '+str(e))
        print('ERROR: '+str(e),file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':sys.exit(main())
