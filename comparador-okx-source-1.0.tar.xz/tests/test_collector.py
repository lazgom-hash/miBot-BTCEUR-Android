import sys, pathlib, unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent.parent/'comparador-okx'))
import collector as c

class TestBook(unittest.TestCase):
 def book(self):
  return {'bids':[(100.0,1),(99.0,2)],'asks':[(101.0,1),(102.0,2)],'mid':100.5,'ts':100000,'age_ms':1000,'bid':100,'ask':101,'spread_bps':99.5025}
 def test_market_fills(self):
  b=self.book()
  self.assertAlmostEqual(c.buy_with_quote(b['asks'],50.5),.5)
  self.assertAlmostEqual(c.sell_btc(b['bids'],.5),50)
  self.assertIsNone(c.buy_with_quote(b['asks'],5000))
  self.assertIsNone(c.sell_btc(b['bids'],5))
 def test_cost(self):
  b=self.book()
  v=c.roundtrip_bps(b,50.5)
  expected=(1-(50*(1-.001))/(50.5*(1+.001)))*10000
  self.assertAlmostEqual(v,expected)
 def test_book_validation(self):
  sample={'bids':[['100','2','0','1'],['99','3','0','1']],
          'asks':[['101','1','0','1'],['102','4','0','1']],'ts':'100000'}
  b=c.parse_book(sample,101000)
  self.assertAlmostEqual(b['spread_bps'],1/100.5*10000)
  self.assertRaises(ValueError,c.parse_book,sample,200000)
  sample['bids'][0][0]='102'
  self.assertRaises(ValueError,c.parse_book,sample,101000)
 def test_quote_equivalence(self):
  b=self.book()
  eur=c.to_row(b,'EUR','BTC-EUR',1.1,'2026-10-30T12:00:00Z')
  usd=c.to_row(b,'USD','BTC-USD',1.1,'2026-10-30T12:00:00Z')
  self.assertIsNotNone(eur['ida_vuelta_200eur_bps'])
  self.assertIsNotNone(usd['ida_vuelta_200eur_bps'])
  self.assertEqual(eur['cobertura_200eur'],1)
if __name__=='__main__':unittest.main()
